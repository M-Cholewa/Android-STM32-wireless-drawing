package com.example.i_fireworks;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

public class OledGrid extends View {

    //consts
    private static final String TAG = "OledGrid";
    private static final int OLED_HEIGHT = 32;
    private static final int OLED_WIDTH = 128;
    private static final int STROKE_SIZE = 1;

    Context mContext;
    int pixelSize, frameColor, viewHeight = 0, viewWidth = 0;
    boolean shouldDrawGrid = true;



    //draw objects
    RectF pixelRect = new RectF();
    Paint framePaint = new Paint();
    Paint bgPaint = new Paint();
    Path drawingPath = new Path();

    public OledGrid(Context context) {
        super(context);
        init();
    }

    public OledGrid(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public OledGrid(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();

    }

    private void init() {
        mContext = getContext();
        frameColor = ContextCompat.getColor(mContext, R.color.black);
        framePaint.setStyle(Paint.Style.STROKE);
        framePaint.setStrokeWidth(STROKE_SIZE);
        framePaint.setColor(frameColor);

        bgPaint.setAntiAlias(true);
        bgPaint.setColor(ContextCompat.getColor(mContext, R.color.bg_dark));

    }

//    private void blackWhite(Canvas c){
//        Bitmap bmp = ((BitmapDrawable) getContext().getResources().getDrawable(R.drawable.mudkip)).getBitmap();
//        Bitmap pixelatedBmp = Bitmap.createScaledBitmap(bmp, OLED_WIDTH, OLED_HEIGHT, true);
//        Bitmap scaledBmp = Bitmap.createScaledBitmap(pixelatedBmp, viewWidth, viewHeight, true);
//        Bitmap scaledMonochromeBmp = createBlackAndWhite(scaledBmp);
////        ColorMatrix ma = new ColorMatrix();
////        ma.setSaturation(0);
//        Paint paint = new Paint();
////        paint.setColorFilter(new ColorMatrixColorFilter(ma));
//        c.drawBitmap(scaledMonochromeBmp, 0, 0, paint);
//    }
//
//    public static Bitmap createBlackAndWhite(Bitmap src) {
//        int width = src.getWidth();
//        int height = src.getHeight();
//        // create output bitmap
//        Bitmap bmOut = Bitmap.createBitmap(width, height, src.getConfig());
//        // color information
//        int A, R, G, B;
//        int pixel;
//
//        // scan through all pixels
//        for (int x = 0; x < width; ++x) {
//            for (int y = 0; y < height; ++y) {
//                // get pixel color
//                pixel = src.getPixel(x, y);
//                A = Color.alpha(pixel);
//                R = Color.red(pixel);
//                G = Color.green(pixel);
//                B = Color.blue(pixel);
//                int gray = (int) (0.2989 * R + 0.5870 * G + 0.1140 * B);
//
//                // use 128 as threshold, above -> white, below -> black
//                if (gray > 160)
//                    gray = 255;
//                else
//                    gray = 0;
//                // set new pixel color to output bitmap
//                bmOut.setPixel(x, y, Color.argb(A, gray, gray, gray));
//            }
//        }
//        return bmOut;
//    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
//        blackWhite(canvas);
        canvas.drawRect(0,0,viewWidth,viewHeight, bgPaint);

        if (shouldDrawGrid)
            drawGrid(canvas);
        framePaint.setStyle(Paint.Style.FILL);
        //todo change color thing
        frameColor = ContextCompat.getColor(mContext, R.color.design_default_color_error);
        framePaint.setColor(frameColor);
        canvas.drawPath(drawingPath, framePaint);
    }

    private void drawGrid(Canvas canvas) {
//        canvas.drawRect(frame, framePaint);
        framePaint.setStyle(Paint.Style.STROKE);
        //todo change color thing
        frameColor = ContextCompat.getColor(mContext, R.color.HTMLGray);
        framePaint.setColor(frameColor);
        framePaint.setAntiAlias(true);
//        canvas.drawRect(STROKE_SIZE,0, viewWidth,viewHeight-STROKE_SIZE,framePaint);
        for (int x = 0; x <= viewWidth; x += pixelSize) {
            for (int y = 0; y <= viewHeight; y += pixelSize) {
                pixelRect.set(x, y, pixelSize, pixelSize);
                canvas.drawRect(pixelRect, framePaint);
            }
        }
    }

    private void drawPixel(int screenX, int screenY) {
        int pixelX = getXPixelCoordinate(screenX) * pixelSize;
        int pixelY = getYPixelCoordinate(screenY) * pixelSize;
        pixelRect.set(pixelX, pixelY, pixelX + pixelSize, pixelY + pixelSize);
        drawingPath.addRect(pixelRect, Path.Direction.CCW);

//        pixelRect.set(pixelX-pixelSize, pixelY, pixelX, pixelY + pixelSize);
//        drawingPath.addRect(pixelRect, Path.Direction.CCW);
        pixelRect.set(pixelX-pixelSize, pixelY-pixelSize, pixelX + pixelSize, pixelY + pixelSize);
        drawingPath.addRect(pixelRect, Path.Direction.CCW);

//        pixelRect.set(pixelX, pixelY, pixelX + pixelSize, pixelY + pixelSize);
//        drawingPath.addRect(pixelRect, Path.Direction.CCW);
    }

    private int getXPixelCoordinate(int screenX) {
        Log.d(TAG, "getXPixelCoordinate: "+(screenX / pixelSize));

        return screenX / pixelSize;
    }

    private int getYPixelCoordinate(int screenY) {
        Log.d(TAG, "getYPixelCoordinate: "+(screenY / pixelSize));
        return screenY / pixelSize;
    }

    public void clearDisplay() {
        drawingPath.reset();
        invalidate();
    }

    public void setShouldDrawGrid(boolean shouldDrawGrid){
        this.shouldDrawGrid = shouldDrawGrid;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int rX = (int) event.getX();
        int rY = (int) event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                drawPixel(rX, rY);
                break;
            case MotionEvent.ACTION_MOVE:
                final int historySize = event.getHistorySize();
                final int pointerCount = event.getPointerCount();
                for (int h = 0; h < historySize; h++) {
                    for (int p = 0; p < pointerCount; p++) {
                        drawPixel((int)event.getHistoricalX(p, h), (int)event.getHistoricalY(p, h));
                    }
                }
//                drawPixel(rX, rY);
                break;
            case MotionEvent.ACTION_UP:
                Log.d(TAG, "onTouchEvent: ACTION UP");
                break;
        }
        invalidate();
        return true;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        viewWidth = MeasureSpec.getSize(widthMeasureSpec);
        pixelSize = (viewWidth - 2 * STROKE_SIZE) / OLED_WIDTH;
        viewWidth = OLED_WIDTH * pixelSize;
        viewHeight = OLED_HEIGHT * pixelSize;
        Log.d(TAG, "onMeasure: pixelSize" + pixelSize);
        Log.d(TAG, "onMeasure: viewWidth" + viewWidth);

        this.setMeasuredDimension(viewWidth, viewHeight);
    }
}
